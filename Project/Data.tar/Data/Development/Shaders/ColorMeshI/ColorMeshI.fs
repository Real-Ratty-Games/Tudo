$input v_texcoord0, v_color

#include <common.sh>

void main()
{
	gl_FragColor = v_color;
}
