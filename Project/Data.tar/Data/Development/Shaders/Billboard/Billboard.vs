$input a_position, a_texcoord0
$output v_texcoord0

#include <common.sh>

uniform vec4 u_transform;
uniform vec4 u_flags;

void main()
{
	vec3 worldPos = u_model[0][3].xyz;
    vec3 right = u_view[0].xyz;

	vec3 up = u_view[1].xyz;
	if(u_flags.x >= 1.0)
		up = normalize(vec3(0.0, u_view[1].y, 0.0));

    vec2 quad = a_position.xy;
	quad -= u_transform.zw;

    vec3 offset = right * quad.x * u_transform.x
                + up    * quad.y * u_transform.y;

    vec4 pos = vec4(worldPos + offset, 1.0);
    gl_Position = mul(u_proj, mul(u_view, pos));
    v_texcoord0 = a_texcoord0;
}
