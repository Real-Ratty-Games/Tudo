$input v_texcoord0, v_dir

#include <common.sh>

SAMPLERCUBE(s_envMap, 0);

void main()
{
	gl_FragColor = textureCube(s_envMap, v_dir);
}
