vec2 v_texcoord0 : TEXCOORD0 = vec2(0.0, 0.0);
vec4 v_atlasInfo : TEXCOORD1 = vec4(0.0, 0.0, 0.0, 0.0);
vec4 v_color 	 : TEXCOORD2 = vec4(1.0, 1.0, 1.0, 1.0);

vec2 a_position  : POSITION;
vec2 a_texcoord0 : TEXCOORD0;
vec4 i_data0     : TEXCOORD7;
vec4 i_data1     : TEXCOORD6;
vec4 i_data2     : TEXCOORD5;
vec4 i_data3     : TEXCOORD4;
vec4 i_data4     : TEXCOORD3;
