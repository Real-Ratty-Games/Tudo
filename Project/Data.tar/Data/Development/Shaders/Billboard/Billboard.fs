$input v_texcoord0

#include <common.sh>

SAMPLER2D(s_texColor, 0);
uniform vec4 color;

void main()
{
	gl_FragColor = texture2D(s_texColor, v_texcoord0) * color;
}
